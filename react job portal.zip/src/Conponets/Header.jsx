function Header() {


  
  return (
    <>
      <div className="navbar-area bg-f0f4fc">
        <div className="mobile-responsive-nav">
          <div className="container">
            <div className="mobile-responsive-menu">
              <div className="logo">
                <a href="index.html">
                  <img
                    src="assets/images/logo.png"
                    className="main-logo"
                    alt="logo"
                  />
                  <img
                    src="assets/images/white-logo.png"
                    className="white-logo"
                    alt="logo"
                  />
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className="desktop-nav">
          <div className="container-fluid">
            <nav className="navbar navbar-expand-md navbar-light">
              <a className="navbar-brand" href="index.html">
                <img
                  src="assets/images/logo.png"
                  className="main-logo"
                  alt="logo"
                />
                <img
                  src="assets/images/white-logo.png"
                  className="white-logo"
                  alt="logo"
                />
              </a>
              <div
                className="collapse navbar-collapse mean-menu"
                id="navbarSupportedContent"
              >
                <ul className="navbar-nav me-auto">
                  <li className="nav-item">
                    <a href="#" className="nav-link dropdown-toggle active">
                      Home
                    </a>
                    <ul className="dropdown-menu">
                      <li className="nav-item">
                        <a href="index.html" className="nav-link active">
                          Home Demo One
                        </a>
                      </li>
                      <li className="nav-item">
                        <a href="index-2.html" className="nav-link">
                          Home Demo Two
                        </a>
                      </li>
                      <li className="nav-item">
                        <a href="index-3.html" className="nav-link">
                          Home Demo Three
                        </a>
                      </li>
                    </ul>
                  </li>
                  <li className="nav-item">
                    <a href="#" className="nav-link dropdown-toggle">
                      Pages
                    </a>
                    <ul className="dropdown-menu">
                      <li className="nav-item">
                        <a href="about-us.html" className="nav-link">
                          About Us
                        </a>
                      </li>
                      <li className="nav-item">
                        <a href="#" className="nav-link dropdown-toggle">
                          Freelancer
                        </a>
                        <ul className="dropdown-menu">
                          <li className="nav-item">
                            <a href="freelancer.html" className="nav-link">
                              Freelancer
                            </a>
                          </li>
                          <li className="nav-item">
                            <a
                              href="freelancer-details.html"
                              className="nav-link"
                            >
                              Freelancer Details
                            </a>
                          </li>
                        </ul>
                      </li>
                      <li className="nav-item">
                        <a href="#" className="nav-link dropdown-toggle">
                          Company
                        </a>
                        <ul className="dropdown-menu">
                          <li className="nav-item">
                            <a href="company.html" className="nav-link">
                              Company Listing
                            </a>
                          </li>
                          <li className="nav-item">
                            <a href="company-details.html" className="nav-link">
                              Company Details
                            </a>
                          </li>
                        </ul>
                      </li>
                      <li className="nav-item">
                        <a href="search-job.html" className="nav-link">
                          Search Job
                        </a>
                      </li>
                      <li className="nav-item">
                        <a href="pricing.html" className="nav-link">
                          Pricing
                        </a>
                      </li>
                      <li className="nav-item">
                        <a href="testimonials.html" className="nav-link">
                          Testimonials
                        </a>
                      </li>
                      <li className="nav-item">
                        <a href="faq.html" className="nav-link">
                          FAQ
                        </a>
                      </li>
                      <li className="nav-item">
                        <a href="contact.html" className="nav-link">
                          Contact us
                        </a>
                      </li>
                      <li className="nav-item">
                        <a href="#" className="nav-link dropdown-toggle">
                          Users
                        </a>
                        <ul className="dropdown-menu">
                          <li className="nav-item">
                            <a href="login.html" className="nav-link">
                              Login
                            </a>
                          </li>
                          <li className="nav-item">
                            <a href="register.html" className="nav-link">
                              Register
                            </a>
                          </li>
                          <li className="nav-item">
                            <a
                              href="recover-password.html"
                              className="nav-link"
                            >
                              Recover Password
                            </a>
                          </li>
                        </ul>
                      </li>
                      <li className="nav-item">
                        <a href="privacy-policy.html" className="nav-link">
                          Privacy Policy
                        </a>
                      </li>
                      <li className="nav-item">
                        <a href="terms-conditions.html" className="nav-link">
                          Terms And Conditions
                        </a>
                      </li>
                      <li className="nav-item">
                        <a href="coming-soon.html" className="nav-link">
                          Coming Soon
                        </a>
                      </li>
                      <li className="nav-item">
                        <a href="404.html" className="nav-link">
                          404 Page
                        </a>
                      </li>
                    </ul>
                  </li>
                  <li className="nav-item">
                    <a href="#" className="nav-link dropdown-toggle">
                      Jobs
                    </a>
                    <ul className="dropdown-menu">
                      <li className="nav-item">
                        <a href="job-listing.html" className="nav-link">
                          Job Listing
                        </a>
                      </li>
                      <li className="nav-item">
                        <a href="post-job.html" className="nav-link">
                          Post A Job
                        </a>
                      </li>
                      <li className="nav-item">
                        <a href="job-details.html" className="nav-link">
                          Job Details
                        </a>
                      </li>
                    </ul>
                  </li>
                  <li className="nav-item">
                    <a href="#" className="nav-link dropdown-toggle">
                      Employers
                    </a>
                    <ul className="dropdown-menu">
                      <li className="nav-item">
                        <a href="employers.html" className="nav-link">
                          Employers Listing
                        </a>
                      </li>
                      <li className="nav-item">
                        <a href="employers-details.html" className="nav-link">
                          Employers Details
                        </a>
                      </li>
                    </ul>
                  </li>
                  <li className="nav-item">
                    <a href="#" className="nav-link dropdown-toggle">
                      Candidates
                    </a>
                    <ul className="dropdown-menu">
                      <li className="nav-item">
                        <a href="candidates.html" className="nav-link">
                          Candidates Listing
                        </a>
                      </li>
                      <li className="nav-item">
                        <a href="candidates-details.html" className="nav-link">
                          Candidates Details
                        </a>
                      </li>
                      <li className="nav-item">
                        <a href="#" className="nav-link dropdown-toggle">
                          Dashboard
                        </a>
                        <ul className="dropdown-menu">
                          <li className="nav-item">
                            <a href="dashboard.html" className="nav-link">
                              Dashboard
                            </a>
                          </li>
                          <li className="nav-item">
                            <a
                              href="dashboard-post-job.html"
                              className="nav-link"
                            >
                              Post A Job
                            </a>
                          </li>
                          <li className="nav-item">
                            <a href="manage-jobs.html" className="nav-link">
                              Manage Jobs
                            </a>
                          </li>
                          <li className="nav-item">
                            <a
                              href="manage-applicants.html"
                              className="nav-link"
                            >
                              Manage Applicants
                            </a>
                          </li>
                          <li className="nav-item">
                            <a href="bookmark.html" className="nav-link">
                              Bookmark Resumes
                            </a>
                          </li>
                          <li className="nav-item">
                            <a href="packages.html" className="nav-link">
                              Packages
                            </a>
                          </li>
                          <li className="nav-item">
                            <a href="messages.html" className="nav-link">
                              Messages
                            </a>
                          </li>
                          <li className="nav-item">
                            <a href="profile.html" className="nav-link">
                              My Profile
                            </a>
                          </li>
                          <li className="nav-item">
                            <a href="change-password.html" className="nav-link">
                              Change Password
                            </a>
                          </li>
                        </ul>
                      </li>
                    </ul>
                  </li>
                  <li className="nav-item">
                    <a href="#" className="nav-link dropdown-toggle">
                      Blog
                    </a>
                    <ul className="dropdown-menu">
                      <li className="nav-item">
                        <a href="blog-grid.html" className="nav-link">
                          Blog Grid
                        </a>
                      </li>
                      <li className="nav-item">
                        <a href="blog-right-sidebar.html" className="nav-link">
                          Blog Right Sidebar
                        </a>
                      </li>
                      <li className="nav-item">
                        <a href="blog-details.html" className="nav-link">
                          Blog Details
                        </a>
                      </li>
                    </ul>
                  </li>
                </ul>
                <div className="others-options">
                  <div className="option-item">
                    <a href="login.html" className="default-btn btn style-2">
                      <i className="fa-regular fa-user" /> Login / Register
                    </a>
                  </div>
                  <div className="option-item">
                    <a href="post-job.html" className="default-btn btn">
                      Post New Job
                    </a>
                  </div>
                </div>
              </div>
            </nav>
          </div>
        </div>
        <div className="others-option-for-responsive">
          <div className="container">
            <div className="dot-menu">
              <div className="inner">
                <div className="circle circle-one" />
                <div className="circle circle-two" />
                <div className="circle circle-three" />
              </div>
            </div>
            <div className="container">
              <div className="option-inner">
                <div className="others-options justify-content-center d-flex align-items-center">
                  <div className="others-options">
                    <div className="option-item">
                      <a href="login.html" className="default-btn btn style-2">
                        <i className="fa-regular fa-user" /> Login / Register
                      </a>
                    </div>
                    <div className="option-item">
                      <a href="post-job.html" className="default-btn btn">
                        Post New Job
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Header;
