import Footer from "./Conponets/Footer";
import Header from "./Conponets/Header";
import Home from "./Conponets/Home";

function App() {
  return (
    <>
      <Header />
      <Home />
      <Footer />
    </>
  );
}

export default App;
